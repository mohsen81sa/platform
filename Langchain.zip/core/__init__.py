from .celery import app as core

__all__ = ('core',)