from django.db.models.signals import post_save
from django.dispatch import receiver
from django_celery_beat.models import PeriodicTask, CrontabSchedule
from .models import CampaignSchedule
import json


@receiver(post_save, sender=CampaignSchedule)
def create_or_update_periodic_task(sender, instance, created, **kwargs):
    cron_parts = instance.crontab_schedule.strip().split()

    if len(cron_parts) != 5:
        return  # یا raise ValidationError برای فرمت اشتباه

    crontab, _ = CrontabSchedule.objects.get_or_create(
        minute=cron_parts[0],
        hour=cron_parts[1],
        day_of_week=cron_parts[2],
        month_of_year=cron_parts[3],
        day_of_month=cron_parts[4],
    )

    task_name = f"Run Campaign {instance.campaign.id} Schedule {instance.id}"

    PeriodicTask.objects.update_or_create(
        name=task_name,
        defaults={
            'task': 'accounts.tasks.run_campaign',
            'crontab': crontab,
            'args': json.dumps([instance.campaign.id]),
            'enabled': instance.is_enabled,
        }
    )