from celery import shared_task
from .models import Campaign

@shared_task
def schedule_campaign_posts():
    print("✅ Running schedule_campaign_posts task...")

    active_campaigns = Campaign.objects.filter(is_active=True, status='active')
    print(f"Found {active_campaigns.count()} active campaigns.")

    for campaign in active_campaigns:
        print(f"Processing campaign: {campaign.title}")
        # اینجا می‌تونی کارهای دیگه انجام بدی